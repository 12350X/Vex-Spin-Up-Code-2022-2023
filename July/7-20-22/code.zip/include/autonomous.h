

class autonomous
{
  public:
    void prompt();
};