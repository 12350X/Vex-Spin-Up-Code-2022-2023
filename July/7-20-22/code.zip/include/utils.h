
#include <vex.h>

  typedef char *string;
  void printlnColored(string args, color c);
  void printColored(string args, color c);
  void printAtColored(int x, int y, bool opaque, string args, color c);
  void kill(thread current_thread);
