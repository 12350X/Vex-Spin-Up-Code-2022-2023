namespace utils{
  typedef char *string;
  template <typename T>
  void println(T const & args);
}
      